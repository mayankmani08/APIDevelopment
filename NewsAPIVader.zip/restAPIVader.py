import requests
import json
import pandas as pd
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from flask import Flask
from flask_restful import Resource, Api, reqparse
import pandas as pd
import ast

class mydict(dict):
        def __str__(self):
            return json.dumps(self)

def SentimentAnalysis():
    analyzer = SentimentIntensityAnalyzer()

    apiKey="3133513f7461466eb70ef9e490761675"
    link="https://newsapi.org/v2/top-headlines?country=in&pageSize=100&apiKey="+apiKey
    print(link)
    response = requests.get(link)
    
    jsonInput=response.text
    jsonInput=jsonInput[jsonInput.find("["):].replace("}]}","}]")
    jsonOutput="["

    with open("inputJson.json","w",encoding="utf-8") as input:
        input.write(jsonInput)

    with open("inputJson.json",encoding="utf-8") as json_file:
        newsAPIData=json.load(json_file)
        
        for news in newsAPIData:
            sentence=news["title"]
            vs = analyzer.polarity_scores(sentence)
            news["polarity"]=vs
            news=mydict(news)
            jsonOutput=jsonOutput+str(news)+","

    jsonOutput=jsonOutput[:len(jsonOutput)-1]
    jsonOutput=jsonOutput+"]"
    #print(jsonOutput)
    with open("outputJson.json","w",encoding="utf-8") as output:
        output.write(jsonOutput)

    # with open("outputJson.json",encoding="utf-8") as json_file:
    #     newsAPIData=json.load(json_file)
    #     print(type(newsAPIData))

class News(Resource):
    def get(self):
        with open("outputJson.json",encoding="utf-8") as json_file:
            newsAPIData=json.load(json_file)
        data=newsAPIData
        return {'data': data}, 200


app = Flask(__name__)
api = Api(app)
api.add_resource(News,'/api/news')

if __name__ == '__main__':
    SentimentAnalysis()
    app.run()